---
title: QuantVAT
emoji: 📊
colorFrom: gray
colorTo: gray
sdk: docker
pinned: true
license: mit
short_description: Quantitative crypto volume analysis toolkit
thumbnail: >-
  https://cdn-uploads.huggingface.co/production/uploads/6947519e94e1623904a5b3a4/sRe5FNlJDAutBTv0dt9CT.jpeg
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference